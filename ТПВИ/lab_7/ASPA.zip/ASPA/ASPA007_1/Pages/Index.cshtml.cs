using DAL_Celebrity;
using DAL_Celebrity_MSSQL;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASPA007_1.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IRepository<Celebrity, Lifeevent> _repo;

        public List<Celebrity> Celebrities { get; set; } = new();

        public IndexModel(IRepository<Celebrity, Lifeevent> repo)
        {
            _repo = repo;
        }

        public void OnGet()
        {
            Celebrities = _repo.GetAllCelebrities();
        }
    }
}
